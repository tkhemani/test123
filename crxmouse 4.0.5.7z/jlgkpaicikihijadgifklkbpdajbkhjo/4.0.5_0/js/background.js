/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 96);
/******/ })
/************************************************************************/
/******/ ({

/***/ 100:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(setImmediate, process) {var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;// MIT license (by Elan Shanker).
(function(globals) {
  'use strict';

  var nextTick = function (fn) {
    if (typeof setImmediate === 'function') {
      setImmediate(fn);
    } else if (typeof process !== 'undefined' && process.nextTick) {
      process.nextTick(fn);
    } else {
      setTimeout(fn, 0);
    }
  };

  var makeIterator = function (tasks) {
    var makeCallback = function (index) {
      var fn = function () {
        if (tasks.length) {
          tasks[index].apply(null, arguments);
        }
        return fn.next();
      };
      fn.next = function () {
        return (index < tasks.length - 1) ? makeCallback(index + 1): null;
      };
      return fn;
    };
    return makeCallback(0);
  };
  
  var _isArray = Array.isArray || function(maybeArray){
    return Object.prototype.toString.call(maybeArray) === '[object Array]';
  };

  var waterfall = function (tasks, callback) {
    callback = callback || function () {};
    if (!_isArray(tasks)) {
      var err = new Error('First argument to waterfall must be an array of functions');
      return callback(err);
    }
    if (!tasks.length) {
      return callback();
    }
    var wrapIterator = function (iterator) {
      return function (err) {
        if (err) {
          callback.apply(null, arguments);
          callback = function () {};
        } else {
          var args = Array.prototype.slice.call(arguments, 1);
          var next = iterator.next();
          if (next) {
            args.push(wrapIterator(next));
          } else {
            args.push(callback);
          }
          nextTick(function () {
            iterator.apply(null, args);
          });
        }
      };
    };
    wrapIterator(makeIterator(tasks))();
  };

  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function () {
      return waterfall;
    }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)); // RequireJS
  } else if (typeof module !== 'undefined' && module.exports) {
    module.exports = waterfall; // CommonJS
  } else {
    globals.asyncWaterfall = waterfall; // <script>
  }
})(this);

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(101).setImmediate, __webpack_require__(18)))

/***/ }),

/***/ 101:
/***/ (function(module, exports, __webpack_require__) {

var apply = Function.prototype.apply;

// DOM APIs, for completeness

exports.setTimeout = function() {
  return new Timeout(apply.call(setTimeout, window, arguments), clearTimeout);
};
exports.setInterval = function() {
  return new Timeout(apply.call(setInterval, window, arguments), clearInterval);
};
exports.clearTimeout =
exports.clearInterval = function(timeout) {
  if (timeout) {
    timeout.close();
  }
};

function Timeout(id, clearFn) {
  this._id = id;
  this._clearFn = clearFn;
}
Timeout.prototype.unref = Timeout.prototype.ref = function() {};
Timeout.prototype.close = function() {
  this._clearFn.call(window, this._id);
};

// Does not start the time, just sets up the members needed.
exports.enroll = function(item, msecs) {
  clearTimeout(item._idleTimeoutId);
  item._idleTimeout = msecs;
};

exports.unenroll = function(item) {
  clearTimeout(item._idleTimeoutId);
  item._idleTimeout = -1;
};

exports._unrefActive = exports.active = function(item) {
  clearTimeout(item._idleTimeoutId);

  var msecs = item._idleTimeout;
  if (msecs >= 0) {
    item._idleTimeoutId = setTimeout(function onTimeout() {
      if (item._onTimeout)
        item._onTimeout();
    }, msecs);
  }
};

// setimmediate attaches itself to the global object
__webpack_require__(102);
exports.setImmediate = setImmediate;
exports.clearImmediate = clearImmediate;


/***/ }),

/***/ 102:
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global, process) {(function (global, undefined) {
    "use strict";

    if (global.setImmediate) {
        return;
    }

    var nextHandle = 1; // Spec says greater than zero
    var tasksByHandle = {};
    var currentlyRunningATask = false;
    var doc = global.document;
    var registerImmediate;

    function setImmediate(callback) {
      // Callback can either be a function or a string
      if (typeof callback !== "function") {
        callback = new Function("" + callback);
      }
      // Copy function arguments
      var args = new Array(arguments.length - 1);
      for (var i = 0; i < args.length; i++) {
          args[i] = arguments[i + 1];
      }
      // Store and register the task
      var task = { callback: callback, args: args };
      tasksByHandle[nextHandle] = task;
      registerImmediate(nextHandle);
      return nextHandle++;
    }

    function clearImmediate(handle) {
        delete tasksByHandle[handle];
    }

    function run(task) {
        var callback = task.callback;
        var args = task.args;
        switch (args.length) {
        case 0:
            callback();
            break;
        case 1:
            callback(args[0]);
            break;
        case 2:
            callback(args[0], args[1]);
            break;
        case 3:
            callback(args[0], args[1], args[2]);
            break;
        default:
            callback.apply(undefined, args);
            break;
        }
    }

    function runIfPresent(handle) {
        // From the spec: "Wait until any invocations of this algorithm started before this one have completed."
        // So if we're currently running a task, we'll need to delay this invocation.
        if (currentlyRunningATask) {
            // Delay by doing a setTimeout. setImmediate was tried instead, but in Firefox 7 it generated a
            // "too much recursion" error.
            setTimeout(runIfPresent, 0, handle);
        } else {
            var task = tasksByHandle[handle];
            if (task) {
                currentlyRunningATask = true;
                try {
                    run(task);
                } finally {
                    clearImmediate(handle);
                    currentlyRunningATask = false;
                }
            }
        }
    }

    function installNextTickImplementation() {
        registerImmediate = function(handle) {
            process.nextTick(function () { runIfPresent(handle); });
        };
    }

    function canUsePostMessage() {
        // The test against `importScripts` prevents this implementation from being installed inside a web worker,
        // where `global.postMessage` means something completely different and can't be used for this purpose.
        if (global.postMessage && !global.importScripts) {
            var postMessageIsAsynchronous = true;
            var oldOnMessage = global.onmessage;
            global.onmessage = function() {
                postMessageIsAsynchronous = false;
            };
            global.postMessage("", "*");
            global.onmessage = oldOnMessage;
            return postMessageIsAsynchronous;
        }
    }

    function installPostMessageImplementation() {
        // Installs an event handler on `global` for the `message` event: see
        // * https://developer.mozilla.org/en/DOM/window.postMessage
        // * http://www.whatwg.org/specs/web-apps/current-work/multipage/comms.html#crossDocumentMessages

        var messagePrefix = "setImmediate$" + Math.random() + "$";
        var onGlobalMessage = function(event) {
            if (event.source === global &&
                typeof event.data === "string" &&
                event.data.indexOf(messagePrefix) === 0) {
                runIfPresent(+event.data.slice(messagePrefix.length));
            }
        };

        if (global.addEventListener) {
            global.addEventListener("message", onGlobalMessage, false);
        } else {
            global.attachEvent("onmessage", onGlobalMessage);
        }

        registerImmediate = function(handle) {
            global.postMessage(messagePrefix + handle, "*");
        };
    }

    function installMessageChannelImplementation() {
        var channel = new MessageChannel();
        channel.port1.onmessage = function(event) {
            var handle = event.data;
            runIfPresent(handle);
        };

        registerImmediate = function(handle) {
            channel.port2.postMessage(handle);
        };
    }

    function installReadyStateChangeImplementation() {
        var html = doc.documentElement;
        registerImmediate = function(handle) {
            // Create a <script> element; its readystatechange event will be fired asynchronously once it is inserted
            // into the document. Do so, thus queuing up the task. Remember to clean up once it's been called.
            var script = doc.createElement("script");
            script.onreadystatechange = function () {
                runIfPresent(handle);
                script.onreadystatechange = null;
                html.removeChild(script);
                script = null;
            };
            html.appendChild(script);
        };
    }

    function installSetTimeoutImplementation() {
        registerImmediate = function(handle) {
            setTimeout(runIfPresent, 0, handle);
        };
    }

    // If supported, we should attach to the prototype of global, since that is where setTimeout et al. live.
    var attachTo = Object.getPrototypeOf && Object.getPrototypeOf(global);
    attachTo = attachTo && attachTo.setTimeout ? attachTo : global;

    // Don't get fooled by e.g. browserify environments.
    if ({}.toString.call(global.process) === "[object process]") {
        // For Node.js before 0.9
        installNextTickImplementation();

    } else if (canUsePostMessage()) {
        // For non-IE10 modern browsers
        installPostMessageImplementation();

    } else if (global.MessageChannel) {
        // For web workers, where supported
        installMessageChannelImplementation();

    } else if (doc && "onreadystatechange" in doc.createElement("script")) {
        // For IE 6–8
        installReadyStateChangeImplementation();

    } else {
        // For older browsers
        installSetTimeoutImplementation();
    }

    attachTo.setImmediate = setImmediate;
    attachTo.clearImmediate = clearImmediate;
}(typeof self === "undefined" ? typeof global === "undefined" ? this : global : self));

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(5), __webpack_require__(18)))

/***/ }),

/***/ 14:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var analytics = function () {
    function analytics() {
        _classCallCheck(this, analytics);

       
        (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
                (i[r].q = i[r].q || []).push(arguments);
            }, i[r].l = 1 * new Date();
            a = s.createElement(o), m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m);
        })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');

        ga('create', 'UA-45823005-3', 'auto');
        ga('set', 'checkProtocolTask', function () {});

       
       
        this.samplingData = [{ category: 'main kpis', action: 'gesture completed', sample: 100 }, { category: 'main kpis', sample: 1 }, { category: 'settings navigation', sample: 1 }, { category: 'general settings', sample: 1 }, { category: 'mouse gestures', sample: 1 }, { category: 'super drag', sample: 1 }, { category: 'scrolling', sample: 1 }, { category: 'wheel gesture', sample: 1 }, { category: 'rocker gesture', sample: 1 }, { category: 'advanced settings', sample: 1 }, { category: 'about', sample: 1 }, { category: 'general', sample: 1 }];
    }

    _createClass(analytics, [{
        key: 'sendEvent',
        value: function sendEvent(category, action, label, value) {

            if (!localStorage.getItem("installedAt")) {
                localStorage.setItem("installedAt", 'N/A');
            }

            ga('send', 'event', category, action, label, value);
        }
    }, {
        key: 'activeUserEvent',
        value: function activeUserEvent(type, timeSince) {
            this.sendEvent("Main KPIs", type + " Active user", timeSince || 'N/A');
        }
    }, {
        key: 'dailyActiveUserTracking',
        value: function dailyActiveUserTracking() {

            var userAge = parseInt(this.getUserAge());
            if (Math.random() < 0.001) {
                this.sendEvent("debug", "userAge", userAge === "N/A" ? "missing" : userAge);
            }
            localStorage.setItem("age", userAge);
            var lastAge = parseInt(localStorage.getItem("lastAge") || 0);
            var timeSince = userAge - (lastAge || 0);
            localStorage.setItem("lastAge", userAge);

            if (userAge === 1 && !localStorage.getItem("D1")) {
                localStorage.setItem("D1", timeSince);
                this.activeUserEvent("D1", timeSince);
            } else if (userAge === 7 && !localStorage.getItem("D7")) {
                localStorage.setItem("D7", timeSince);
                this.activeUserEvent("D7", timeSince);
            } else if (userAge === 14 && !localStorage.getItem("D14")) {
                localStorage.setItem("D14", timeSince);
                this.activeUserEvent("D14", timeSince);
            } else if (userAge === 28 && !localStorage.getItem("D28")) {
                localStorage.setItem("D28", timeSince);
                this.activeUserEvent("D28", timeSince);
            } else if (userAge === 90 && !localStorage.getItem("D90")) {
                localStorage.setItem("D90", timeSince);
                this.activeUserEvent("D90", timeSince);
            }
        }
    }, {
        key: 'setDailyUserTracking',
        value: function setDailyUserTracking() {
            this.dailyActiveUserTracking();
            setInterval(this.dailyActiveUserTracking.bind(this), 1000 * 60 * 5);
        }
    }, {
        key: 'getUserAge',
        value: function getUserAge() {
            if (!localStorage.getItem("installedAt") || isNaN(localStorage.getItem("installedAt"))) {
                return 'N/A';
            } else {
                return Math.floor((new Date().getTime() - localStorage.getItem("installedAt")) / (1000 * 60 * 60 * 24));
            }
        }
    }, {
        key: 'gaAnalyticsEvent',
        value: function gaAnalyticsEvent(category, action, label, value) {

            if (!category) return;

            var _iteratorNormalCompletion = true;
            var _didIteratorError = false;
            var _iteratorError = undefined;

            try {
                for (var _iterator = this.samplingData[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
                    var event = _step.value;

                    if (event.category === category.toLowerCase() && (event.action && event.action === action.toLowerCase() || !event.action)) {
                        if (event.sample > 0 && Math.floor(event.sample * Math.random()) + 1 === 1) {
                            this.sendEvent(category, action, label, value);
                        }
                        return;
                    }
                }
            } catch (err) {
                _didIteratorError = true;
                _iteratorError = err;
            } finally {
                try {
                    if (!_iteratorNormalCompletion && _iterator.return) {
                        _iterator.return();
                    }
                } finally {
                    if (_didIteratorError) {
                        throw _iteratorError;
                    }
                }
            }

            this.sendEvent(category, action, label, value);
        }
    }]);

    return analytics;
}();

exports.default = new analytics();

/***/ }),

/***/ 15:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
var URLS = {
    REPORT_BUG_URL: 'https://docs.google.com/forms/d/e/1FAIpQLSd_kyu5sZBjw2bGVFEWAg5kxsIPtEQSwW5j3gvR6wAhBO_BjQ/viewform'
};

var storageKeys = {
    UPDATE_NOTIFICATION: 'sawUpdateNotification'
};

exports.URLS = URLS;
exports.storageKeys = storageKeys;

/***/ }),

/***/ 18:
/***/ (function(module, exports) {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),

/***/ 30:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };


var supportedKeys = ['cfgver', 'drag', 'gesture', 'isOnboardingShownOnce', 'others', 'scroll', 'scrollgesture', 'strokegesture', 'optedout', 'lastEditedGesture'];

var getState = function getState(cb) {
    chrome.storage.sync.get(function (state) {
        return cb(state);
    });
};

var setState = function setState(state, cb) {
    chrome.storage.sync.set(state, function () {
        localStorage.setItem("config", JSON.stringify(_extends({}, JSON.parse(localStorage.config), state)));
        cb();
    });
};

var filterState = function filterState(state) {
    return Object.keys(state).filter(function (key) {
        return supportedKeys.includes(key);
    }).reduce(function (obj, key) {
        obj[key] = state[key];
        return obj;
    }, {});
};

var shouldSyncState = function shouldSyncState(currState, previousState) {
    return JSON.stringify(currState).localeCompare(JSON.stringify(previousState)) !== 0 ? true : false;
};

exports.getState = getState;
exports.setState = setState;
exports.filterState = filterState;
exports.shouldSyncState = shouldSyncState;

/***/ }),

/***/ 5:
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || Function("return this")() || (1,eval)("this");
} catch(e) {
	// This works if the window reference is available
	if(typeof window === "object")
		g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),

/***/ 96:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(97);


/***/ }),

/***/ 97:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _analytics = __webpack_require__(14);

var _analytics2 = _interopRequireDefault(_analytics);

var _defaultConfig = __webpack_require__(98);

var _defaultConfig2 = _interopRequireDefault(_defaultConfig);

var _migration = __webpack_require__(99);

var _constants = __webpack_require__(15);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

window.config = {};
window.isRocker = false;

var isDailyTrackingWasSet = false;
window.closedTabs = {};
window.closedTabsId = [];
var lastTabs = {};
var lastTabsId = [];

var openOptions = function openOptions() {
    var t = chrome.tabs;
    t.query({ url: "chrome-extension://" + chrome.runtime.id + "/options.html" }, function (tabs) {
        if (tabs && tabs.length !== 0) {
            t.update(tabs[0].id, { active: true });
        } else {
            t.create({ url: "options.html" });
        }
    });
};

chrome.storage.sync.get("optedout", function (obj) {
    chrome.browserAction.setIcon({
        path: !obj["optedout"] ? "icon.png" : "icond.png"
    });
});

if (!localStorage.getItem("config")) {
    config = JSON.parse(JSON.stringify(_defaultConfig2.default));
    localStorage.setItem("config", JSON.stringify(_defaultConfig2.default));
} else {
    config = JSON.parse(localStorage.getItem("config"));
}

config.extid = chrome.runtime.id ? chrome.runtime.id : "none";


if (!localStorage.getItem("cmfirst") || JSON.parse(localStorage.getItem("openoptspage"))) {
    chrome.windows.getAll({ populate: true }, function (windows) {
        for (var i = 0; i < windows.length; i++) {
            for (var ii = 0; ii < windows[i].tabs.length; ii++) {
                try {
                    if (windows[i]) {
                        if (windows[i].tabs[ii].url.indexOf('chrome://') == -1) {
                            chrome.tabs.executeScript(windows[i].tabs[ii].id, {
                                file: "js/jquery-3.3.1.min.js",
                                allFrames: true,
                                runAt: "document_start"
                            }, function () {
                                if (windows[i]) {
                                    chrome.tabs.executeScript(windows[i].tabs[ii].id, {
                                        file: "js/event.js",
                                        allFrames: true,
                                        runAt: "document_start"
                                    });
                                }
                            });
                        }
                    }
                } catch (e) {
                    console.log(e);
                }
            }
        }
    });

    localStorage.setItem("cmfirst", 1);
    localStorage.setItem("openoptspage", false);
   
}

var checksave = false;
var notifiEnable = false;
if (config.normal.minilength === undefined) {
    notifiEnable = true;
}
for (var i in _defaultConfig2.default.normal) {
    if (config.normal[i] === undefined) {
        config.normal[i] = _defaultConfig2.default.normal[i];
        checksave = true;
    }
}
if (config.scroll === undefined) {
    config.scroll = {};
    config.normal.scroll = false;
    checksave = true;
}
for (var i in _defaultConfig2.default.scroll) {
    if (config.scroll[i] === undefined) {
        config.scroll[i] = _defaultConfig2.default.scroll[i];
        checksave = true;
    }
}
if (config.gesture.gesture === undefined) {
    checksave = true;
    var _cgesture = config.gesture;
    config.gesture = {};
    for (var i in _defaultConfig2.default.gesture) {
       
        config.gesture[i] = _defaultConfig2.default.gesture[i];
    }
    config.gesture.gesture = _cgesture;

    var _ctext = config.text;
    var _clink = config.link;
    var _cimage = config.image;
    config.drag = {};
    for (var i in _defaultConfig2.default.drag) {
        config.drag[i] = _defaultConfig2.default.drag[i];
        checksave = true;
    }
    config.drag.text = _ctext;
    config.drag.link = _clink;
    config.drag.image = _cimage;
    delete config.text;
    delete config.link;
    delete config.image;

    config.scrollgesture = _defaultConfig2.default.scrollgesture;
}
if (config.drag.draginput === undefined) {
    config.drag.draginput = _defaultConfig2.default.drag.draginput;
    checksave = true;
}
if (config.drag.setdragurl === undefined) {
    config.drag.setdragurl = _defaultConfig2.default.drag.setdragurl;
    checksave = true;
}
if (config.gesture.geskey === undefined) {
    config.gesture.geskey = _defaultConfig2.default.gesture.geskey;
    config.gesture.stenable = _defaultConfig2.default.gesture.stenable;
    config.gesture.gholdkey = _defaultConfig2.default.gesture.gholdkey;
    config.drag.imgfirstcheck = _defaultConfig2.default.drag.imgfirstcheck;
    config.drag.imgfirst = _defaultConfig2.default.drag.imgfirst;
    config.drag.dholdkey = _defaultConfig2.default.drag.dholdkey;
    checksave = true;
}
if (!config.strokegesture) {
    config.strokegesture = {};
    config.strokegesture = _defaultConfig2.default.strokegesture;
    config.scrollgesture = {};
    config.scrollgesture = _defaultConfig2.default.scrollgesture;
    checksave = true;
}
if (!config.cfgver) {
    var upgrade2 = function upgrade2(obj1, obj2) {
        for (var i = 0; i < config[obj1][obj2].length; i++) {
            var cfg2gesture = config[obj1][obj2][i];
            if (cfg2gesture.action == "G_reclosedtab") {
                cfg2gesture.moreTarget = "newfront";
                cfg2gesture.morePosition = "chrome";
                cfg2gesture.morePinned = "unpinned";
                cfg2gesture.moreDes = chrome.i18n.getMessage("G_reclosedtab");
            } else if (cfg2gesture.action == "G_crxsettings") {
                cfg2gesture.moreDes = chrome.i18n.getMessage("G_crxsettings");
                cfg2gesture.morePinned = "unpinned";
                cfg2gesture.morePosition = posvalue;
                cfg2gesture.moreTarget = "newfront";
            } else if (cfg2gesture.action == "G_newusertab") {
                cfg2gesture.moreName = config[obj1][obj2][i].more1;
                cfg2gesture.moreURL = config[obj1][obj2][i].more2;
                cfg2gesture.moreDes = chrome.i18n.getMessage("valuenewusertab");
                cfg2gesture.morePinned = "unpinned";
                cfg2gesture.morePosition = posvalue;
                cfg2gesture.moreTarget = "newfront";
            } else if (cfg2gesture.action == "G_newusertabback") {
                cfg2gesture.action = "G_newusertab";
                cfg2gesture.moreName = config[obj1][obj2][i].more1;
                cfg2gesture.moreURL = config[obj1][obj2][i].more2;
                cfg2gesture.moreDes = chrome.i18n.getMessage("valuenewusertab");
                cfg2gesture.morePinned = "unpinned";
                cfg2gesture.morePosition = posvalue;
                cfg2gesture.moreTarget = "newback";
            } else if (cfg2gesture.action == "G_newusertabcur") {
                cfg2gesture.action = "G_newusertab";
                cfg2gesture.moreName = config[obj1][obj2][i].more1;
                cfg2gesture.moreURL = config[obj1][obj2][i].more2;
                cfg2gesture.moreDes = chrome.i18n.getMessage("valuenewusertab");
                cfg2gesture.morePinned = "unpinned";
                cfg2gesture.morePosition = posvalue;
                cfg2gesture.moreTarget = "curfront";
            } else if (cfg2gesture.action == "G_settings" || cfg2gesture.action == "G_downloads" || cfg2gesture.action == "G_bookmarks" || cfg2gesture.action == "G_history") {
                cfg2gesture.moreDes = chrome.i18n.getMessage("valuechromepage");
                cfg2gesture.morePinned = "unpinned";
                cfg2gesture.morePosition = posvalue;
                cfg2gesture.moreTarget = "newfront";
                cfg2gesture.moreChromepage = "cr" + cfg2gesture.action.substr(2);
                cfg2gesture.action = "G_chromepage";
            } else if (cfg2gesture.action == "G_newtab") {
                cfg2gesture.action = "G_newtab";
                cfg2gesture.moreDes = chrome.i18n.getMessage("G_newtab");
                cfg2gesture.morePinned = "unpinned";
                cfg2gesture.morePosition = posvalue;
                cfg2gesture.moreTarget = "newfront";
            } else if (cfg2gesture.action == "G_newtabback") {
                cfg2gesture.action = "G_newtab";
                cfg2gesture.moreDes = chrome.i18n.getMessage("G_newtab");
                cfg2gesture.morePinned = "unpinned";
                cfg2gesture.morePosition = posvalue;
                cfg2gesture.moreTarget = "newback";
            } else if (cfg2gesture.action == "G_viewsource") {
                cfg2gesture.action = "G_viewsource";
                cfg2gesture.moreDes = chrome.i18n.getMessage("G_viewsource");
                cfg2gesture.morePinned = "unpinned";
                cfg2gesture.morePosition = posvalue;
                cfg2gesture.moreTarget = "newfront";
            } else if (cfg2gesture.action == "G_userscript") {
                cfg2gesture.action = "G_userscript";
                cfg2gesture.moreName = cfg2gesture.more1;
                cfg2gesture.moreScript = cfg2gesture.more2;
                cfg2gesture.moreDes = cfg2gesture.des;
            }

            if (config[obj1][obj2][i].more1) {
                delete config[obj1][obj2][i].more1;
            }
            if (config[obj1][obj2][i].more2) {
                delete config[obj1][obj2][i].more2;
            }
            if (config[obj1][obj2][i].des) {
                delete config[obj1][obj2][i].des;
            }
        }
    };

    var posvalue = config.normal.newtabposition;

    upgrade2("gesture", "gesture");
    upgrade2("scrollgesture", "sgsleft");
    upgrade2("scrollgesture", "sgsright");
    upgrade2("strokegesture", "strleft");
    upgrade2("strokegesture", "strright");

    for (var i = 0; i < config.drag.text.length; i++) {
        var cfg2text = config.drag.text[i];
        if (config.drag.text[i].action == "T_gsearch") {
            cfg2text.action = "T_search";
            cfg2text.moreDes = chrome.i18n.getMessage("valuetsearch") + "(" + chrome.i18n.getMessage("newfront") + ")";
            cfg2text.morePinned = "unpinned";
            cfg2text.morePosition = "chrome";
            cfg2text.moreTarget = "newfront";
            cfg2text.moreTsearch = "sgoogle";
        } else if (config.drag.text[i].action == "T_gsearchback") {
            cfg2text.action = "T_search";
            cfg2text.moreDes = chrome.i18n.getMessage("valuetsearch") + "(" + chrome.i18n.getMessage("newback") + ")";
            cfg2text.morePinned = "unpinned";
            cfg2text.morePosition = "chrome";
            cfg2text.moreTarget = "newback";
            cfg2text.moreTsearch = "sgoogle";
        } else if (config.drag.text[i].action == "T_searchuser") {
            cfg2text.action = "T_searchuser";
            cfg2text.moreDes = config.drag.text[i].des;
            cfg2text.moreName = config.drag.text[i].more1;
            cfg2text.morePinned = "unpinned";
            cfg2text.morePosition = "chrome";
            cfg2text.moreTarget = "newfront";
            cfg2text.moreURL = config.drag.text[i].more2;
        } else if (config.drag.text[i].action == "T_searchuserback") {
            cfg2text.action = "T_searchuser";
            cfg2text.moreDes = config.drag.text[i].des;
            cfg2text.moreName = config.drag.text[i].more1;
            cfg2text.morePinned = "unpinned";
            cfg2text.morePosition = "chrome";
            cfg2text.moreTarget = "newback";
            cfg2text.moreURL = config.drag.text[i].more2;
        } else if (config.drag.text[i].action == "T_sbaidu" || config.drag.text[i].action == "T_sbing" || config.drag.text[i].action == "T_syandex" || config.drag.text[i].action == "T_syahoo" || config.drag.text[i].action == "T_swiki" || config.drag.text[i].action == "T_staobao" || config.drag.text[i].action == "T_samazon") {
            cfg2text.action = "T_search";
            cfg2text.moreDes = chrome.i18n.getMessage("valuetsearch") + "(" + chrome.i18n.getMessage("newfront") + ")";
            cfg2text.morePinned = "unpinned";
            cfg2text.morePosition = "chrome";
            cfg2text.moreTarget = "newfront";
            cfg2text.moreTsearch = "s" + config.drag.text[i].action.substr(3);
        } else if (config.drag.text[i].action == "T_sbaiduback" || config.drag.text[i].action == "T_sbingback" || config.drag.text[i].action == "T_syandexback" || config.drag.text[i].action == "T_syahooback" || config.drag.text[i].action == "T_swikiback" || config.drag.text[i].action == "T_staobaoback" || config.drag.text[i].action == "T_samazonback") {
            cfg2text.action = "T_search";
            cfg2text.moreDes = chrome.i18n.getMessage("valuetsearch") + "(" + chrome.i18n.getMessage("newback") + ")";
            cfg2text.morePinned = "unpinned";
            cfg2text.morePosition = "chrome";
            cfg2text.moreTarget = "newback";
            cfg2text.moreTsearch = "s" + config.drag.text[i].action.substr(3, config.drag.text[i].action.length - 7);
        }

        if (config.drag.text[i].more1) {
            delete config.drag.text[i].more1;
        }
        if (config.drag.text[i].more2) {
            delete config.drag.text[i].more2;
        }
        if (config.drag.text[i].des) {
            delete config.drag.text[i].des;
        }
    }

    for (var i = 0; i < config.drag.link.length; i++) {
        var cfg2link = config.drag.link[i];
        if (config.drag.link[i].action == "L_openback") {
            cfg2link.action = "L_open";
            cfg2link.moreDes = chrome.i18n.getMessage("L_open") + "(" + chrome.i18n.getMessage("newback") + ")";
            cfg2link.morePinned = "unpinned";
            cfg2link.morePosition = "chrome";
            cfg2link.moreTarget = "newback";
        } else if (config.drag.link[i].action == "L_open") {
            cfg2link.action = "L_open";
            cfg2link.moreDes = chrome.i18n.getMessage("L_open") + "(" + chrome.i18n.getMessage("newfront") + ")";
            cfg2link.morePinned = "unpinned";
            cfg2link.morePosition = "chrome";
            cfg2link.moreTarget = "newfront";
        }
        if (config.drag.link[i].more1) {
            delete config.drag.link[i].more1;
        }
        if (config.drag.link[i].more2) {
            delete config.drag.link[i].more2;
        }
        if (config.drag.link[i].des) {
            delete config.drag.link[i].des;
        }
    }

    for (var i = 0; i < config.drag.image.length; i++) {
        var cfg2image = config.drag.image[i];
        if (config.drag.image[i].action == "I_open") {
            cfg2image.action = "I_open";
            cfg2image.moreDes = chrome.i18n.getMessage("I_open") + "(" + chrome.i18n.getMessage("newfront") + ")";
            cfg2image.morePinned = "unpinned";
            cfg2image.morePosition = "chrome";
            cfg2image.moreTarget = "newfront";
        } else if (config.drag.image[i].action == "I_openback") {
            cfg2image.action = "I_open";
            cfg2image.moreDes = chrome.i18n.getMessage("I_open") + "(" + chrome.i18n.getMessage("newback") + ")";
            cfg2image.morePinned = "unpinned";
            cfg2image.morePosition = "chrome";
            cfg2image.moreTarget = "newback";
        } else if (config.drag.image[i].action == "I_sgoogle" || config.drag.image[i].action == "I_sbaidu" || config.drag.image[i].action == "I_stineye") {
            cfg2image.action = "I_search";
            cfg2image.moreDes = chrome.i18n.getMessage("valueisearch");
            cfg2image.morePinned = "unpinned";
            cfg2image.morePosition = "chrome";
            cfg2image.moreTarget = "newfront";
            cfg2image.moreIsearch = config.drag.image[i].action.substr(2) + "image";
        } else if (config.drag.image[i].action == "I_sgoogleback" || config.drag.image[i].action == "I_sbaiduback" || config.drag.image[i].action == "I_stineyeback") {
            cfg2image.action = "I_search";
            cfg2image.moreDes = chrome.i18n.getMessage("valueisearch");
            cfg2image.morePinned = "unpinned";
            cfg2image.morePosition = "chrome";
            cfg2image.moreTarget = "newback";
            cfg2image.moreIsearch = config.drag.image[i].action.substr(2, config.drag.image[i].action.length - 6) + "image";
        }
        if (config.drag.image[i].more1) {
            delete config.drag.image[i].more1;
        }
        if (config.drag.image[i].more2) {
            delete config.drag.image[i].more2;
        }
        if (config.drag.image[i].des) {
            delete config.drag.image[i].des;
        }
    }

    config.cfgver = 2;
    checksave = true;
}
if (config.cfgver < 2.1) {
    for (var i = 0; i < config.gesture.gesture.length; i++) {
        if (config.gesture.gesture[i].action == "G_close") {
            if (config.normal.lasttab) {
                config.gesture.gesture[i].moreCloseopts = "unclose";
            } else {
                config.gesture.gesture[i].moreCloseopts = "close";
            }
            config.gesture.gesture[i].moreCloseurl = "chrome://newtab/";
            config.gesture.gesture[i].moreClosesel = "chrome";
        }
    }
    config.cfgver = 2.1;
    checksave = true;
}
if (config.cfgver < 2.2) {
    config.others = {};
    config.others.tuilink = false;
    config.cfgver = 2.2;
    checksave = true;
}
if (config.cfgver < 2.3) {
    for (i = 0; i < config.gesture.gesture.length; i++) {
        if (config.gesture.gesture[i].action == "G_close") {
            config.gesture.gesture[i].moreCloseopts = "close";
            config.gesture.gesture[i].moreClosesel = "chrome";
            config.gesture.gesture[i].moreCloseurl = "chrome://newtab/";
        }
    }
    config.cfgver = 2.3;
    checksave = true;
}

config.gesture.gesture.forEach(function (e, i) {
    if (!config.gesture.gesture[i].whitelist) {
        config.gesture.gesture[i].whitelist = [];
        checksave = true;
    }
});

if (checksave) {
    localStorage.setItem("config", JSON.stringify(config));
    checksave = false;
    if (config.sync) {
       
        chrome.storage.sync.set(config, function () {});
    }
}

if (!config.sync) {
    chrome.storage.sync.get(null, function (items) {
        if (!items.sync) {
            config.sync = true;
            localStorage.setItem("config", JSON.stringify(config));
            chrome.storage.sync.set(config, function () {});
        } else {
            chrome.storage.sync.get(null, function (items) {
                localStorage.setItem("config", JSON.stringify(items));
            });
        }
    });
} else if (config.sync == "local") {
   
    config.sync = true;
    chrome.storage.sync.set(config, function () {});
} else {
    chrome.storage.sync.get(null, function (items) {
        localStorage.setItem("config", JSON.stringify(items));
    });
}
config = JSON.parse(localStorage.getItem("config"));

if (notifiEnable) {
    var updatetext = "";
    if (window.navigator.language == "zh-CN") {
        updatetext = "Gestures for Chrome(TM)汉化版 已经更新,并更名为CrxMouse.";
    } else if (window.navigator.language == "zh-TW") {
        updatetext = "Gestures for Chrome(TM)繁體版已經更新,並更名為CrxMouse.";
    } else {
        updatetext = "Gestures for Chrome(TM) Plus has been updated,and renamed to CrxMouse.";
    }
    chrome.runtime.onInstalled.addListener(function (details) {
        if (details.reason == "update") {
            var notification = webkitNotifications.createNotification('icon.png',
            "CrxMouse",
            updatetext
            );
            notification.show();
        }
    });
}

chrome.tabs.onRemoved.addListener(function (tabId, removeInfo) {
    closedTabs["id" + tabId] = lastTabs["id" + tabId];
    closedTabsId.push(lastTabs["id" + tabId]);
    for (var id in lastTabsId) {
        if (lastTabsId[id].id == tabId) {}
    }
});
chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
    lastTabs["id" + tab.id] = tab;
    var _flag = true;
    for (var i = 0; i < lastTabsId.length; i++) {
        if (lastTabsId[i].id == tabId) {
            _flag = false;
            lastTabsId[i] = tab;
            break;
        }
    }
    if (_flag) {
        lastTabsId.push(tab);
    }
});
chrome.runtime.onInstalled.addListener(function (details) {
    try {
        if (localStorage.getItem(_constants.storageKeys.UPDATE_NOTIFICATION) === null) {
            localStorage.setItem(_constants.storageKeys.UPDATE_NOTIFICATION, JSON.stringify(false));
        }
    } catch (e) {
       
    }

    if (details.reason === "install") {
        try {
            localStorage.setItem(_constants.storageKeys.UPDATE_NOTIFICATION, JSON.stringify(true));
        } catch (e) {
           
        }
        chrome.tabs.create({ url: "https://crxmouse.com/welcome", active: true }, function () {});
        localStorage.setItem("installedAt", new Date().getTime());
        _analytics2.default.gaAnalyticsEvent("Main KPIs", "Extension installed");
        if (!isDailyTrackingWasSet) {
            isDailyTrackingWasSet = true;
            _analytics2.default.setDailyUserTracking();
        }
    } else if (details.reason === "update") {
        if (!localStorage.getItem("installedAt")) {
            localStorage.setItem("installedAt", 'n/a');
        } else {
            if (!isDailyTrackingWasSet) {
                isDailyTrackingWasSet = true;
                _analytics2.default.setDailyUserTracking();
            }
        }
        if (localStorage.getItem("cmfirst")) {
           
            localStorage.showUpdatedInfo = 0;
            localStorage.cmfirst = 1;
        }
        (0, _migration.migrateState)(details, function () {});
    }
});

chrome.runtime.setUninstallURL("https://crxmouse.com/uninstall");
if (!isDailyTrackingWasSet) {
    isDailyTrackingWasSet = true;
    _analytics2.default.setDailyUserTracking();
}

/***/ }),

/***/ 98:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    isOnboardingShownOnce: false,
    isGesturesOff: false,
    cfgver: 2.3,
    others: {
        tuilink: false
    },
    normal: {
        gesture: true,
        drag: true,
        scroll: false,
        scrollgesture: false,
        strokegesture: false,
        autocancel: false,
        autocancelvalue: 2,
        lasttab: false,
        scrolleffects: true,
        newtabposition: "chrome",

        minilength: 10,
        capturetype: "jpeg",
        jpegquality: 100,
        cancelcontextmenu: true,
        dbclicktime: 600
    },
    gesture: {
        gestureui: true,
        stroke: true,
        direct: true,
        tooltip: true,
        strokecolor: "4E1485",
        strokewidth: 5,
        strokeopa: 0.8,
        directcolor: "5E6A88",
        directopa: 0.9,
        tooltipcolor: "120310",
        tooltipwidth: 18,
        tooltipopa: 0.9,
        geskey: "right",
        stenable: false,
        gholdkey: "none",
        gesPos: "cc",
        gesture: [{
            direct: "L",
            action: "G_back",
            whitelist: []
        }, {
            direct: "R",
            action: "G_go",
            whitelist: []
        }, {
            direct: "U",
            action: "G_up",
            whitelist: []
        }, {
            direct: "D",
            action: "G_down",
            whitelist: []
        }, {
            direct: "DR",
            action: "G_close",
            moreCloseopts: "close",
            moreClosesel: "chrome",
            moreCloseurl: "chrome://newtab/",
            whitelist: []
        }, {
            direct: "LU",
            action: "G_reclosedtab",
            moreTarget: "newfront",
            morePosition: "chrome",
            morePinned: "unpinned",
            moreDes: chrome.i18n.getMessage("G_reclosedtab"),
            whitelist: []
        }, {
            direct: "RD",
            action: "G_bottom",
            whitelist: []
        }, {
            direct: "RU",
            action: "G_top",
            whitelist: []
        }, {
            direct: "UD",
            action: "G_reload",
            whitelist: []
        }, {
            direct: "UDU",
            action: "G_reloadclear",
            whitelist: []
        }, {
            direct: "UL",
            action: "G_lefttab",
            whitelist: []
        }, {
            direct: "UR",
            action: "G_righttab",
            whitelist: []
        }, {
            direct: "DRU",
            action: "G_newwindow",
            whitelist: []
        }, {
            direct: "URD",
            action: "G_closewindow",
            whitelist: []
        }, {
            direct: "RDLU",
            action: "G_crxsettings",
            moreDes: chrome.i18n.getMessage("G_crxsettings"),
            morePinned: "unpinned",
            morePosition: "chrome",
            moreTarget: "newfront",
            whitelist: []
        }]
    },
    drag: {
        dragui: true,
        dstroke: true,
        ddirect: true,
        dtooltip: true,
        dstrokecolor: "4E1485",
        dstrokewidth: 5,
        dstrokeopa: 0.8,
        ddirectcolor: "5E6A88",
        ddirectopa: 0.9,
        dtooltipcolor: "120310",
        dtooltipwidth: 18,
        dtooltipopa: 0.9,
        dragtext: true,
        draglink: true,
        dragimage: true,
        draginput: false,
        setdragurl: true,
        imgfirstcheck: false,
        imgfirst: "none",
        dholdkey: "none",

        text: [{
            direct: "L",
            action: "T_search",
            moreDes: chrome.i18n.getMessage("valuetsearch") + "(" + chrome.i18n.getMessage("newback") + ")",
            morePinned: "unpinned",
            morePosition: "chrome",
            moreTarget: "newback",
            moreTsearch: "sgoogle"
        }, {
            direct: "R",
            action: "T_search",
            moreDes: chrome.i18n.getMessage("valuetsearch") + "(" + chrome.i18n.getMessage("newfront") + ")",
            morePinned: "unpinned",
            morePosition: "chrome",
            moreTarget: "newfront",
            moreTsearch: "sgoogle"
        }, {
            direct: "D",
            action: "T_copytext"
        }],
        link: [{
            direct: "L",
            action: "L_open",
            moreDes: chrome.i18n.getMessage("L_open") + "(" + chrome.i18n.getMessage("newback") + ")",
            morePinned: "unpinned",
            morePosition: "chrome",
            moreTarget: "newback"
        }, {
            direct: "R",
            action: "L_open",
            moreDes: chrome.i18n.getMessage("L_open") + "(" + chrome.i18n.getMessage("newfront") + ")",
            morePinned: "unpinned",
            morePosition: "chrome",
            moreTarget: "newfront"
        }, {
            direct: "D",
            action: "L_copytext"
        }, {
            direct: "U",
            action: "L_copyurl"
        }],
        image: [{
            direct: "L",
            action: "I_open",
            moreDes: chrome.i18n.getMessage("I_open") + "(" + chrome.i18n.getMessage("newback") + ")",
            morePinned: "unpinned",
            morePosition: "chrome",
            moreTarget: "newback"
        }, {
            direct: "R",
            action: "I_open",
            moreDes: chrome.i18n.getMessage("I_open") + "(" + chrome.i18n.getMessage("newfront") + ")",
            morePinned: "unpinned",
            morePosition: "chrome",
            moreTarget: "newfront"
        }, {
            direct: "D",
            action: "I_save"
        }]
    },
    scroll: {
        smooth: true,
        scrollspeed: 3,
        scrollaccele: 1
    },
    scrollgesture: {
        tablist: true,
        tablistkey: "right",
        tablistVisual: true,
        sgsleftenable: true,
        sgsrightenable: false,
        sgsleft: [{ action: "G_top" }, { action: "G_bottom" }],
        sgsright: [{ action: "G_top" }, { action: "G_bottom" }],
        fastSwitch: false,
        reverseFS: false

    },
    strokegesture: {
        strpress: "up",
        strleftenable: true,
        strleft: [{ action: "G_none" }, { action: "G_righttab" }],
        strmiddleenable: false,
        strmiddle: [{ action: "G_lefttab" }, { action: "G_righttab" }],
        strrightenable: true,
        strright: [{ action: "G_lefttab" }, { action: "G_none" }]
    }
};

/***/ }),

/***/ 99:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.migrateState = undefined;

var _storage = __webpack_require__(30);

var _asyncWaterfall = __webpack_require__(100);

var _asyncWaterfall2 = _interopRequireDefault(_asyncWaterfall);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var migrateTo400Version = function migrateTo400Version(cb) {

    (0, _storage.getState)(function (oldStore) {

        oldStore.isOnboardingShownOnce = false;
        oldStore.isGesturesOff = false;

        (0, _storage.setState)(oldStore, function () {
            localStorage.setItem("config", JSON.stringify(oldStore));
            cb();
        });
    });
};

var migrateState = function migrateState(details, callback) {

    var lastVersion = details.previousVersion;
    var lastVersionNum = lastVersion.split('.').join('');
    var currentVersion = chrome.runtime.getManifest().version;

    if (lastVersion === currentVersion) {
        return;
    }

    (0, _asyncWaterfall2.default)([

        function (cb) {
        if (lastVersionNum >= 400) cb();else {
            migrateTo400Version(cb);
        }
    }], function () {
        callback();
    });
};

exports.migrateState = migrateState;

/***/ })

/******/ });