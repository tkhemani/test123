/*
 * i18n.js
 *
 * Internationalization support
 *
*/
function I18N(name) {
    return chrome.i18n.getMessage(name);
}
